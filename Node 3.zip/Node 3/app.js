const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const port = 80;

// EXPRESS SPECIFIC STUFF
app.use(express.urlencoded())

// ENDPOINTS
app.get('/', (req, res)=>{
    let fileread = fs.readFileSync("./page/index.html");
    res.end(fileread);
});

app.post('/', (req, res)=>{
    const CompaneyName = req.body.CompaneyName;
    const Companeydescription = req.body.Companeydescription;
    const BrandName = req.body.BrandName;
    const Branddescription = req.body.Branddescription;
    const Businessselectforstate = req.body.Businessselectforstate;
    const Brandlogo = req.body.Brandlogo;
    let outputToWrite = `{The client Companey Name is: ${CompaneyName},
    Companeydescription is: ${Companeydescription}, 
    Brand Name is: ${BrandName}, 
    Brand description: ${Branddescription}, 
    Business for a state is: ${Businessselectforstate}, 
    Brand logo is: ${Brandlogo}}`;
    fs.writeFileSync(`./views/${CompaneyName}`, outputToWrite);
    let fileread = fs.readFileSync("./page/index.html");
    res.end(fileread);
});


// START THE SERVER
app.listen(port, ()=>{
    console.log(`The application started successfully port ${port}`);
});
